# Appliance Energy Prediction

Capstone project for Udacity Machine Learning Nanodegree

### Early Work

* [Research Paper](http://dx.doi.org/10.1016/j.enbuild.2017.01.083)           <br>
* [GitHub repo](https://github.com/LuisM78/Appliances-energy-prediction-data)

### Dataset Link

* [Appliance Energy Data](http://archive.ics.uci.edu/ml/datasets/Appliances+energy+prediction)

### Dataset Information

* Number of instances: 19,735
* Number of attributes: 29

